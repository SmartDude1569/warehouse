return {
	search = require('screens.search')(),
	home = require('screens.home')()
}