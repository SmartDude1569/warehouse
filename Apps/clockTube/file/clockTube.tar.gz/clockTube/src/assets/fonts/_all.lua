return {
	SegoeUI = love.graphics.newFont('assets/fonts/Segoe UI.ttf'),
	SegoeUI_big = love.graphics.newFont('assets/fonts/Segoe UI.ttf', 15),
	SegoeUI_light = love.graphics.newFont('assets/fonts/Segoe UI Light.ttf'),
	SegoeUI_bold = love.graphics.newFont('assets/fonts/Segoe UI Bold.ttf'),
	SegoeUI_bold_medium = love.graphics.newFont('assets/fonts/Segoe UI Bold.ttf', 14),
	SegoeUI_bold_huge = love.graphics.newFont('assets/fonts/Segoe UI Bold.ttf', 18)
}