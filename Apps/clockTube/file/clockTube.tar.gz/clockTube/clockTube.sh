#!/bin/bash

git pull

love ./src > log.txt 2>&1